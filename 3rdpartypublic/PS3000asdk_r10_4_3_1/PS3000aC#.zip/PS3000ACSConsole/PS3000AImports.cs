/**************************************************************************
*
* Filename:    PS3000AImports.cs
*
* Copyright:   Pico Technology Limited 2011
*
* Author:      MJL
*
* Description:
*   This file contains all the .NET wrapper calls needed to support
*   the console example. It also has the enums and structs required
*   by the (wrapped) function calls.
*
* History:
*    14Dec06	MJL	Created
* 	 15Oct09	RPM Modified for PS4000
* 	 23Nov11    CPY Modified for PS3000A

*
* Revision Info: "file %n date %f revision %v"
*						""
*
***************************************************************************/

using System;
using System.Runtime.InteropServices;
using System.Text;

namespace PS3000ACSConsole
{
	class Imports
	{
		#region constants
		private const string _DRIVER_FILENAME = "ps3000A.dll";

		public const int MaxValue = 32512;

        public const ulong PICO_OK = 0;
        public const ulong PICO_POWER_SUPPLY_CONNECTED = 0x00000119UL;
        public const ulong PICO_POWER_SUPPLY_NOT_CONNECTED = 0x0000011AUL;
        public const ulong PICO_POWER_SUPPLY_REQUEST_INVALID = 0x0000011BUL;
        public const ulong PICO_POWER_SUPPLY_UNDERVOLTAGE = 0x0000011CUL;
		#endregion

		#region Driver enums

		public enum Channel : int
		{
			ChannelA,
			ChannelB,
			ChannelC,
			ChannelD,
			External,
			Aux,
			None,
		}

		public enum Range : int
		{
			Range_10MV,
			Range_20MV,
			Range_50MV,
			Range_100MV,
			Range_200MV,
			Range_500MV,
			Range_1V,
			Range_2V,
			Range_5V,
			Range_10V,
			Range_20V,
			Range_50V,
		}

		public enum ReportedTimeUnits : int
		{
			FemtoSeconds,
			PicoSeconds,
			NanoSeconds,
			MicroSeconds,
			MilliSeconds,
			Seconds,
		}

		public enum ThresholdMode : int
		{
			Level,
			Window
		}

		public enum ThresholdDirection : int
		{
			// Values for level threshold mode
			//
			Above,
			Below,
			Rising,
			Falling,
			RisingOrFalling,

			// Values for window threshold mode
			//
			Inside = Above,
			Outside = Below,
			Enter = Rising,
			Exit = Falling,
			EnterOrExit = RisingOrFalling,
			PositiveRunt = 9,
			NegativeRunt,

			None = Rising,
		}

		public enum DownSamplingMode : int
		{
			None,
			Aggregate
		}

		public enum PulseWidthType : int
		{
			None,
			LessThan,
			GreaterThan,
			InRange,
			OutOfRange
		}

		public enum TriggerState : int
		{
			DontCare,
			True,
			False,
		}

        public enum RatioMode : int
        {
            None,
            Aggregate,
            Average,
            Decimate
        }


		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct TriggerChannelProperties
		{
			public short ThresholdMajor;
			public ushort HysteresisMajor;
			public short ThresholdMinor;
			public ushort HysteresisMinor;
			public Channel Channel;
			public ThresholdMode ThresholdMode;


			public TriggerChannelProperties(
				short thresholdMajor,
				ushort hysteresisMajor,
				short thresholdMinor,
				ushort hysteresisMinor,
				Channel channel,
				ThresholdMode thresholdMode)
			{
				this.ThresholdMajor = thresholdMajor;
				this.HysteresisMajor = hysteresisMajor;
				this.ThresholdMinor = thresholdMinor;
				this.HysteresisMinor = hysteresisMinor;
				this.Channel = channel;
				this.ThresholdMode = thresholdMode;
			}
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct TriggerConditions
		{
			public TriggerState ChannelA;
			public TriggerState ChannelB;
			public TriggerState ChannelC;
			public TriggerState ChannelD;
			public TriggerState External;
			public TriggerState Aux;
			public TriggerState Pwq;

			public TriggerConditions(
				TriggerState channelA,
				TriggerState channelB,
				TriggerState channelC,
				TriggerState channelD,
				TriggerState external,
				TriggerState aux,
				TriggerState pwq)
			{
				this.ChannelA = channelA;
				this.ChannelB = channelB;
				this.ChannelC = channelC;
				this.ChannelD = channelD;
				this.External = external;
				this.Aux = aux;
				this.Pwq = pwq;
			}
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct PwqConditions
		{
			public TriggerState ChannelA;
			public TriggerState ChannelB;
			public TriggerState ChannelC;
			public TriggerState ChannelD;
			public TriggerState External;
			public TriggerState Aux;

			public PwqConditions(
				TriggerState channelA,
				TriggerState channelB,
				TriggerState channelC,
				TriggerState channelD,
				TriggerState external,
				TriggerState aux)
			{
				this.ChannelA = channelA;
				this.ChannelB = channelB;
				this.ChannelC = channelC;
				this.ChannelD = channelD;
				this.External = external;
				this.Aux = aux;
			}
		}
		#endregion

		#region Driver Imports
		#region Callback delegates
		public delegate void ps3000aBlockReady(short handle, short status, IntPtr pVoid);

		public delegate void ps3000aStreamingReady(
												short handle,
												int noOfSamples,
												uint startIndex,
												short ov,
												uint triggerAt,
												short triggered,
												short autoStop,
												IntPtr pVoid);

		public delegate void ps3000DataReady(
												short handle,
                                                short status,
												int noOfSamples,
												short overflow,
												IntPtr pVoid);
		#endregion

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aOpenUnit")]
		public static extern short OpenUnit(out short handle, StringBuilder serial);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aCloseUnit")]
		public static extern short CloseUnit(short handle);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aRunBlock")]
		public static extern short RunBlock(
												short handle,
												int noOfPreTriggerSamples,
												int noOfPostTriggerSamples,
												uint timebase,
												short oversample,
												out int timeIndisposedMs,
												ushort segmentIndex,
												ps3000aBlockReady lpps3000aBlockReady,
												IntPtr pVoid);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aStop")]
		public static extern short Stop(short handle);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetChannel")]
		public static extern short SetChannel(
												short handle,
												Channel channel,
												short enabled,
												short dc,
												Range range,
                                                float analogueOffset);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetDataBuffer")]
		public static extern short SetDataBuffer(
												short handle,
												Channel channel,
												short[] buffer,
												int bufferLth,
                                                ushort segmentIndex,
                                                RatioMode  ratioMode);

        [DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetDataBuffers")]
        public static extern short SetDataBuffers(
                                                short handle,
                                                Channel channel,
                                                short[] bufferMax,
                                                short[] bufferMin,
                                                int bufferLth,
                                                ushort segmentIndex,
                                                RatioMode ratioMode);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetTriggerChannelDirections")]
		public static extern short SetTriggerChannelDirections(
												short handle,
												ThresholdDirection channelA,
												ThresholdDirection channelB,
												ThresholdDirection channelC,
												ThresholdDirection channelD,
												ThresholdDirection ext,
												ThresholdDirection aux);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aGetTimebase")]
		public static extern short GetTimebase(
											 short handle,
											 uint timebase,
											 int noSamples,
											 out int timeIntervalNanoseconds,
											 short oversample,
											 out int maxSamples,
											 ushort segmentIndex);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aGetValues")]
		public static extern short GetValues(
				short handle,
				uint startIndex,
				ref uint noOfSamples,
				uint downSampleRatio,
				DownSamplingMode downSampleRatioMode,
				ushort segmentIndex,
				out short overflow);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetPulseWidthQualifier")]
		public static extern short SetPulseWidthQualifier(
			short handle,
			PwqConditions[] conditions,
			short nConditions,
			ThresholdDirection direction,
			uint lower,
			uint upper,
			PulseWidthType type);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetTriggerChannelProperties")]
		public static extern short SetTriggerChannelProperties(
			short handle,
			TriggerChannelProperties[] channelProperties,
			short nChannelProperties,
			short auxOutputEnable,
			int autoTriggerMilliseconds);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetTriggerChannelConditions")]
		public static extern short SetTriggerChannelConditions(
			short handle,
			TriggerConditions[] conditions,
			short nConditions);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetTriggerDelay")]
		public static extern short SetTriggerDelay(short handle, uint delay);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aGetUnitInfo")]
		public static extern short GetUnitInfo(
            short handle, 
            StringBuilder infoString, 
            short stringLength, 
            out short requiredSize, 
            int info);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aRunStreaming")]
		public static extern short RunStreaming(
			short handle,
			ref uint sampleInterval,
			ReportedTimeUnits sampleIntervalTimeUnits,
			uint maxPreTriggerSamples,
			uint maxPostPreTriggerSamples,
			bool autoStop,
			uint downSamplingRatio,
            RatioMode downSampleRatioMode,
			uint overviewBufferSize);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aGetStreamingLatestValues")]
		public static extern short GetStreamingLatestValues(
			short handle,
			ps3000aStreamingReady lpps3000aStreamingReady,
			IntPtr pVoid);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aSetNoOfCaptures")]
		public static extern short SetNoOfRapidCaptures(
			short handle,
			ushort nCaptures);

		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aMemorySegments")]
		public static extern short MemorySegments(
			short handle,
			ushort nSegments,
			out int nMaxSamples);


		[DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aGetValuesBulk")]
		public static extern short GetValuesRapid(
			short handle,
			ref uint noOfSamples,
			ushort fromSegmentIndex,
			ushort toSegmentIndex,
            uint downSampleRatio,
            DownSamplingMode downSampleRatioMode,
			short[] overflow);

        [DllImport(_DRIVER_FILENAME, EntryPoint = "ps3000aChangePowerSource")]
        public static extern short ChangePowerSource(
            short handle,
            short status);

		#endregion
	}
}
